library(tidyverse)
reviews <- read.csv("employee_reviews_raw.csv")
str(reviews)
summary(reviews)

##Removed irrelevant count column and link column
reviews <- reviews[,-c(1,17)]

##Imputed "none" values with NA to be able to impute new values for missing ones later
reviews$work.balance.stars[reviews$work.balance.stars=="none"] <- NA
reviews$culture.values.stars[reviews$culture.values.stars=="none"] <- NA
reviews$culture.values.stars <- factor(reviews$culture.values.stars)
reviews$carrer.opportunities.stars[reviews$carrer.opportunities.stars =="none"] <- NA
reviews$comp.benefit.stars[reviews$comp.benefit.stars=="none"] <- NA
reviews$senior.mangemnet.stars[reviews$senior.mangemnet.stars=="none"] <- NA

##Converted all the rating variables from factor to numeric
reviews$work.balance.stars <- as.numeric(as.character(as.factor(reviews$work.balance.stars)))
reviews$culture.values.stars <- as.numeric(as.character(as.factor(reviews$culture.values.stars)))
reviews$carrer.opportunities.stars <- as.numeric(as.character(as.factor(reviews$carrer.opportunities.stars)))
reviews$comp.benefit.stars <- as.numeric(as.character(as.factor(reviews$comp.benefit.stars)))
reviews$senior.mangemnet.stars <- as.numeric(as.character(as.factor(reviews$senior.mangemnet.stars)))
summary(reviews)

##Cleaned up column names
names(reviews)
names(reviews) <- c("company", "location", "date", "job_title", "summary", "pros", "cons", "advice_to_mgmt", "overall_rating", "work_balance_stars", "culture_values_stars", "career_opps_stars", "comp_benefit_stars", "senior_mgmt_stars", "helpful_count")

##Replaced missing values section
library(mice)
md.pattern(reviews)
#The matrix plot output gives us a good understanding of how the NA values are distributed in the data (red=NA)

#Selected only the star variables (containing NAs) that need to be imputed 
reviews_onlystars <- reviews %>% select(`work_balance_stars`,`culture_values_stars`, `career_opps_stars`, `comp_benefit_stars`, `senior_mgmt_stars`)

#Imputed missing values using mice
#Scaled data first 
reviews_onlystars_scaled<- apply(reviews_onlystars,2,scale)

#Then imputed
reviews_onlystars_mice <- complete(mice(reviews_onlystars,m=10,maxit=50,meth='norm',seed=500))

#Checked to make sure all NAs were resolved
md.pattern(reviews_onlystars_mice)

#Decided NOT to use mice in this case, since we have a min/max value constraint (range of 1-5) and an increment size limitation (0.5 increments), when imputing values for the NAs
reviews_onlystars_clean <- reviews_onlystars
for(i in 1:ncol(reviews_onlystars_clean)){reviews_onlystars_clean[is.na(reviews_onlystars_clean[,i]), i] <- median(reviews_onlystars_clean[,i], na.rm = TRUE)}
summary(reviews_onlystars_clean)

#Checked to make sure all NAs were resolved
md.pattern(reviews_onlystars_clean)

##Merged clean star variables with original dataset (minus the dirty star variables)
reviews_exclstars <- reviews[,-(10:14)]
reviews_merge <- cbind(reviews_exclstars, reviews_onlystars_clean)
str(reviews_merge)

##Converted date column from factor to date type
library(lubridate)
reviews_merge$date <- mdy(reviews_merge$date)
head(reviews_merge$date)

##Separated job_title column into 2 different columns "employee_status" and "position"
reviews_merge <- reviews_merge %>% separate(job_title, c("employee_status", "position"), sep = " - " )
reviews_merge$employee_status <- as.factor(reviews_merge$employee_status)

##Converted factor variables containing text responses to character type
reviews_merge$summary <- as.character(reviews_merge$summary)
reviews_merge$pros <- as.character(reviews_merge$pros)
reviews_merge$cons <- as.character(reviews_merge$cons)
reviews_merge$advice_to_mgmt <- as.character(reviews_merge$advice_to_mgmt)

##Wrote cleaned data to CSV file
write.csv(reviews_merge, 'employee_reviews_clean.csv',row.names = F)
